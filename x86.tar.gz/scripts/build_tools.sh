#! /bin/sh

###################################################
#                                                 #
# script was built for Debian Wheezy base install.#
#                                                 #
###################################################

apt-get install g++ -y
apt-get install make -y
apt-get install build-essential -y

apt-get install git -y
apt-get install subversion -y


